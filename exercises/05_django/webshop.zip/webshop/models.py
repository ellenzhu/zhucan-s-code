from django.db import models

class Product(models.Model):
  """
  Write your model for the exercise 3 here. Remove the pass text.
  """
  pass
